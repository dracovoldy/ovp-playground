sap.ui.define(["sap/ovp/app/Component"], function(AppComponent) {
    return AppComponent.extend("com.chevron.dcore.analyticspoc.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
